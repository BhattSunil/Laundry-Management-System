import React from 'react'
import './Common.css'
function Common() {
  return (
    <div className='main'>
      <h1>Laundry Management System</h1>
    </div>
  )
}

export default Common
