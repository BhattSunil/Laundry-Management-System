import React, { useEffect, useState } from "react";
import axios from "axios";
import { API } from "../api";
import Common from "./Common";

import "./CustomersPage.css";

function CustomersPage() {
  const [customers, setCustomers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    address: "",
  });
  const [message, setMessage] = useState("");

  const loadCustomers = async () => {
    try {
      const res = await axios.get(`${API}/customers`);
      setCustomers(res.data.data);
    } catch (err) {
      console.error("Error loading customers:", err);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  const handleAddClick = () => {
    setShowForm((prev) => !prev); // toggle form
    setMessage("");
  };

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");

    if (!form.name || !form.phone || !form.address) {
      setMessage("All fields are required.");
      return;
    }

    try {
      const res = await axios.post(`${API}/customers`, form);
      setMessage(res.data.message || "Customer added successfully");
      setForm({ name: "", phone: "", address: "" });
      setShowForm(false);
      loadCustomers();
    } catch (err) {
      console.error("Error adding customer:", err);
      setMessage(
        err.response?.data?.message ||
          "Something went wrong while adding customer."
      );
    }
  };

  return (
    <>
      <Common />

      <div className="customers-container">
        <div className="customers-header">
          <h1 className="customers-title">List of Customers</h1>
          <button className="add-button" onClick={handleAddClick}>
            {showForm ? "Close" : "Add"}
          </button>
        </div>

        {showForm && (
          <form className="customer-form" onSubmit={handleSubmit}>
            <h3>Add New Customer</h3>

            {message && <p className="form-message">{message}</p>}

            <input
              type="text"
              name="name"
              placeholder="Customer Name"
              value={form.name}
              onChange={handleChange}
            />
            <input
              type="text"
              name="phone"
              placeholder="Mobile Number"
              value={form.phone}
              onChange={handleChange}
            />
            <input
              type="text"
              name="address"
              placeholder="Address"
              value={form.address}
              onChange={handleChange}
            />

            <button type="submit" className="submit-button">
              Save Customer
            </button>
          </form>
        )}

        {!showForm && message && <p className="form-message">{message}</p>}

        {customers.length === 0 ? (
          <p>No customers found.</p>
        ) : (
          customers.map((c, index) => (
            <div key={c.id} className="customer-card">
              <div className="customer-name">
                {index + 1}. {c.name}
              </div>
              <div className="customer-info">
                <strong>Phone:</strong> {c.phone}
              </div>
              <div className="customer-info">
                <strong>Address:</strong> {c.address}
              </div>
            </div>
          ))
        )}
      </div>
    </>
  );
}

export default CustomersPage;
